
import React, { useState } from 'react'
import api from '../api'

export default function Login({onAuthed}){
  const [email,setEmail] = useState('admin@tanzadata360.com')
  const [password,setPassword] = useState('admin123')
  const [err,setErr] = useState(null)

  const submit = async (e)=>{
    e.preventDefault()
    setErr(null)
    try{
      const {data} = await api.post('/auth/login',{email,password})
      onAuthed(data.access_token)
    }catch(e){
      setErr('Login failed')
    }
  }

  return (
    <div className="max-w-md mx-auto pt-24">
      <h1 className="text-2xl font-bold mb-4">TanzaData360 Login</h1>
      <form onSubmit={submit} className="space-y-3">
        <input className="border p-2 w-full" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email"/>
        <input className="border p-2 w-full" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password"/>
        {err && <div className="text-red-600 text-sm">{err}</div>}
        <button className="bg-black text-white px-4 py-2 rounded">Login</button>
      </form>
    </div>
  )
}
