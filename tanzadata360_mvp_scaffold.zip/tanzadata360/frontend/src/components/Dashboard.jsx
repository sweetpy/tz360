
import React, { useEffect, useState } from 'react'
import api from '../api'

export default function Dashboard({token}){
  const [kpis,setKpis] = useState(null)

  useEffect(()=>{
    const fetchKpis = async ()=>{
      const {data} = await api.get('/dash/kpis')
      setKpis(data)
    }
    fetchKpis()
  },[])

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Overview</h1>
      {!kpis ? <div>Loading...</div> : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 border rounded bg-white"><div className="text-gray-500 text-sm">Sales</div><div className="text-xl font-bold">{kpis.sales.toLocaleString()}</div></div>
          <div className="p-4 border rounded bg-white"><div className="text-gray-500 text-sm">Volume</div><div className="text-xl font-bold">{kpis.volume.toLocaleString()}</div></div>
          <div className="p-4 border rounded bg-white"><div className="text-gray-500 text-sm">AOV</div><div className="text-xl font-bold">{kpis.aov.toLocaleString()}</div></div>
          <div className="p-4 border rounded bg-white"><div className="text-gray-500 text-sm">Fail Rate</div><div className="text-xl font-bold">{(kpis.fail_rate*100).toFixed(2)}%</div></div>
        </div>
      )}
      <div className="mt-8 p-4 border rounded bg-white">
        <h2 className="font-semibold mb-2">Upload Data</h2>
        <UploadWidget/>
      </div>
    </div>
  )
}

function UploadWidget(){
  const [file,setFile] = useState(null)
  const [result,setResult] = useState(null)

  const upload = async ()=>{
    const form = new FormData()
    form.append('f', file)
    const {data} = await api.post('/ingest/upload', form, { headers: { 'Content-Type':'multipart/form-data' } })
    setResult(data)
  }

  return (
    <div>
      <input type="file" onChange={e=>setFile(e.target.files[0])} className="mb-2"/>
      <button onClick={upload} className="bg-black text-white px-3 py-1 rounded disabled:opacity-50" disabled={!file}>Upload</button>
      {result && <pre className="mt-4 text-xs bg-gray-100 p-2 rounded overflow-auto">{JSON.stringify(result,null,2)}</pre>}
    </div>
  )
}
