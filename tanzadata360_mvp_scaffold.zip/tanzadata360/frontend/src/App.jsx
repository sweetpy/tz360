
import React, { useState } from 'react'
import Login from './components/Login.jsx'
import Dashboard from './components/Dashboard.jsx'

export default function App(){
  const [token, setToken] = useState(null)
  return (
    <div className="min-h-screen bg-gray-50">
      {!token ? <Login onAuthed={setToken}/> : <Dashboard token={token}/>}
    </div>
  )
}
