
-- Minimal schema for MVP demos (expand later)
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS orgs(
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL DEFAULT 'Demo Org',
  tier TEXT DEFAULT 'enterprise',
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS outlets(
  id BIGSERIAL PRIMARY KEY,
  org_id INT REFERENCES orgs(id) DEFAULT 1,
  name TEXT,
  address TEXT,
  region TEXT,
  district TEXT,
  ward TEXT,
  lat DOUBLE PRECISION,
  lon DOUBLE PRECISION,
  channel TEXT,
  status TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products(
  id BIGSERIAL PRIMARY KEY,
  org_id INT REFERENCES orgs(id) DEFAULT 1,
  sku TEXT, name TEXT, category TEXT, uom TEXT, status TEXT
);

CREATE TABLE IF NOT EXISTS transactions(
  id BIGSERIAL PRIMARY KEY,
  org_id INT REFERENCES orgs(id) DEFAULT 1,
  outlet_id BIGINT REFERENCES outlets(id),
  product_id BIGINT REFERENCES products(id),
  txn_ts TIMESTAMP,
  qty INT,
  unit_price NUMERIC(12,2),
  tax NUMERIC(12,2),
  discount NUMERIC(12,2),
  total NUMERIC(12,2),
  payment_method TEXT,
  status_code TEXT,
  device_id TEXT,
  lat DOUBLE PRECISION,
  lon DOUBLE PRECISION
);

CREATE TABLE IF NOT EXISTS insights_daily(
  id BIGSERIAL PRIMARY KEY,
  org_id INT REFERENCES orgs(id) DEFAULT 1,
  outlet_id BIGINT REFERENCES outlets(id),
  kpi_date DATE,
  sales NUMERIC(14,2),
  volume BIGINT,
  aov NUMERIC(12,2),
  fail_rate NUMERIC(6,4),
  score_outlet INT
);
INSERT INTO orgs (name) VALUES ('Demo Org') ON CONFLICT DO NOTHING;
