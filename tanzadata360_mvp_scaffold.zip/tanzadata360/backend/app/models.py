
from sqlalchemy.orm import declarative_base
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.dialects.postgresql import JSONB
from datetime import datetime

Base = declarative_base()

# Models are not strictly required for MVP since we aggregate via SQL.
# Add ORM models here if needed for expansions.
