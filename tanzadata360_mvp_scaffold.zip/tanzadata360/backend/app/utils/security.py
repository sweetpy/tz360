
import os, time, hmac, hashlib, base64
from jose import jwt

SECRET = os.getenv("SECRET_KEY","change-me")
ALGO = "HS256"

def encode_jwt(sub: str, ttl_seconds: int = 86400):
    payload = {"sub": sub, "exp": int(time.time())+ttl_seconds}
    return jwt.encode(payload, SECRET, algorithm=ALGO)

def verify_jwt(token: str):
    try:
        return jwt.decode(token, SECRET, algorithms=[ALGO])
    except Exception:
        return None
