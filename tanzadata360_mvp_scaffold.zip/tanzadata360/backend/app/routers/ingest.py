
from fastapi import APIRouter, UploadFile, File, HTTPException
import os, uuid, pandas as pd

UPLOAD_DIR = "/app/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

router = APIRouter()

@router.post("/upload")
async def upload_file(f: UploadFile = File(...)):
    ext = os.path.splitext(f.filename)[1].lower()
    if ext not in [".csv",".xlsx",".xls"]:
        raise HTTPException(400,"Only CSV/XLSX allowed for MVP")
    newname = f"{uuid.uuid4().hex}{ext}"
    path = os.path.join(UPLOAD_DIR, newname)
    with open(path,"wb") as out:
        out.write(await f.read())
    # TODO: queue ETL job; for now do a quick profile
    try:
        if ext == ".csv":
            df = pd.read_csv(path).head(5)
        else:
            df = pd.read_excel(path).head(5)
        cols = list(df.columns)
        sample = df.to_dict(orient="records")
    except Exception as e:
        raise HTTPException(400, f"Parse error: {e}")
    return {"file_id": newname, "columns": cols, "sample": sample}
