
from fastapi import APIRouter, HTTPException
from ..schemas import Token, LoginRequest
from ..utils.security import encode_jwt

router = APIRouter()

# Simple in-memory user for MVP demo
DEMO_USER = {"email":"admin@tanzadata360.com","password":"admin123","org_id":1}

@router.post("/login", response_model=Token)
def login(body: LoginRequest):
    if body.email == DEMO_USER["email"] and body.password == DEMO_USER["password"]:
        token = encode_jwt(f"{DEMO_USER['org_id']}|{body.email}")
        return {"access_token": token, "token_type":"bearer"}
    raise HTTPException(status_code=401, detail="Invalid credentials")
