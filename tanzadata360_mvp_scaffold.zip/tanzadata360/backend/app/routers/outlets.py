
from fastapi import APIRouter, Query
from typing import List, Dict

router = APIRouter()

@router.get("")
def list_outlets(region: str | None = Query(None), score_min: int = 0) -> List[Dict]:
    # Demo data for MVP wire-up
    return [
        {"id":1,"name":"Mama Jane Duka","region":"Dar es Salaam","lat":-6.8,"lon":39.28,"score_outlet":87},
        {"id":2,"name":"Kilimanjaro Wholesalers","region":"Arusha","lat":-3.37,"lon":36.68,"score_outlet":74},
    ]
