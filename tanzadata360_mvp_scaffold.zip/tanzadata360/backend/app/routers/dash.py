
from fastapi import APIRouter, Query
from ..schemas import KPIResponse

router = APIRouter()

@router.get("/kpis", response_model=KPIResponse)
def kpis(region: str | None = Query(None), date_from: str | None = None, date_to: str | None = None):
    # Placeholder static KPIs; replace with SQL aggregates
    sales = 263452345.0
    volume = 1245321
    aov = round(sales / max(volume,1), 2)
    fail_rate = 0.032
    return {"sales": sales, "volume": volume, "aov": aov, "fail_rate": fail_rate}
