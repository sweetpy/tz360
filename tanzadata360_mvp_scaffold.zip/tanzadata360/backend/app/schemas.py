
from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class LoginRequest(BaseModel):
    email: str
    password: str

class KPIResponse(BaseModel):
    sales: float
    volume: int
    aov: float
    fail_rate: float
