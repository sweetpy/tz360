
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .db import init_db
from .routers import auth, ingest, dash, outlets

import os

app = FastAPI(title="TanzaData360 API", version="0.1.0")

origins = os.getenv("ALLOW_ORIGINS","http://localhost:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    init_db()

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(ingest.router, prefix="/ingest", tags=["ingest"])
app.include_router(dash.router, prefix="/dash", tags=["dashboards"])
app.include_router(outlets.router, prefix="/outlets", tags=["outlets"])

@app.get("/health")
def health():
    return {"status":"ok"}
