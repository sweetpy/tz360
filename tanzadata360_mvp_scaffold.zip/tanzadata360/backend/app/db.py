
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL","postgresql+psycopg://tdata:tdata@db:5432/tdata")

engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_db():
    # Tables are created by SQL scripts loaded on container start.
    # Here we could run migrations later.
    pass
