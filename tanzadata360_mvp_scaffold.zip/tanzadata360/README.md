
# TanzaData360 (MVP Scaffold)

A lean, dockerized skeleton for the FMCG intelligence SaaS. This boots:
- PostgreSQL + PostGIS
- FastAPI backend
- React + Vite + Tailwind frontend
- Metabase (for embedded analytics)

## Prereqs
- Docker & Docker Compose

## Run
```bash
docker compose up --build
```

- Backend: http://localhost:8000/docs
- Frontend: http://localhost:5173
- Metabase: http://localhost:3000

## Default Demo Login
- email: admin@tanzadata360.com
- password: admin123

## Next
- Wire SQL aggregates in `/dash/kpis`
- Replace demo data in `/outlets`
- Point Metabase to `db` (Postgres) and create dashboards; embed via signed URLs later.
- Implement real auth & org-scoped RBAC.
```

